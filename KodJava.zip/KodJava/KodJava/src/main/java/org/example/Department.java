package org.example;

public enum Department
{
    business,
    health,
    history,
    biology,
    psychology,
    engineering,
    it,
    arts,
    education,
    journalism;
    @Override
    public String toString() {
        return super.toString();
    }
}
