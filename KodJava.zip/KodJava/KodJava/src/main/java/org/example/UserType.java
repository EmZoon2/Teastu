package org.example;

public enum UserType
{
    admin,
    teacher,
    student;
    @Override
    public String toString() {
        return super.toString();
    }
}
