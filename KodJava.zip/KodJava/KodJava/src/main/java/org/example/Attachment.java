package org.example;

public class Attachment
{
    private String name;
    private String content;
}
